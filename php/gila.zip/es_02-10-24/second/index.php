<?php
$subjects = array("Maths", "English", "Science", "History", "Geography", "Art", "Music", "Drama", "PE", "IT");

$grades = array();

for ($i = 0; $i < 10; $i++) {
  $subjectGrades = array();
  for ($j = 0; $j < 10; $j++) {
    array_push($subjectGrades, rand(1, 10));
  }
  array_push($grades, $subjectGrades);
}

$passing = array();

foreach ( $grades as $subjectGrades ) {
  $pass = true;
  foreach ( $subjectGrades as $grade ) {
    if ($grade < 6) {
      $pass = false;
      break;
    }
  }
  array_push($passing, $pass);
}

echo "
<html lang='en'>
  <head>
    <title>Grades</title>
    <style>
      table {
        border-collapse: collapse;
      }
      th, td {
        border: 1px solid black;
        padding: 5px;
      }
    </style>
  </head>
  <body>
    <table>
      <thead>
      <tr>
";
foreach ($subjects as $subject) {
  echo "<th><span>$subject</span></th>";
}
echo "</tr>";

echo "</thead>";
echo "<tbody>";

foreach ($grades as $subjectGrades) {
  echo "<tr>";
  foreach ($subjectGrades as $grade) {
    if ($grade < 6) {
      echo "<td style='color: red;'>$grade</td>";
    } else {
      echo "<td>$grade</td>";
    }
  }
  echo "</tr>";
}

echo "<tr>";

foreach ($passing as $pass) {
  if ($pass) {
    echo "<td style='color: green;'>Pass</td>";
  } else {
    echo "<td style='color: red;'>Fail</td>";
  }
}

echo "</tr>";
echo "</tbody>";
echo "</table>";

echo "Overall: ";

if (in_array(false, $passing)) {
  echo "<span style='color: red;'>Fail</span>";
} else {
  echo "<span style='color: green;'>Pass</span>";
}

echo "</body>";
echo "</html>";

?>
